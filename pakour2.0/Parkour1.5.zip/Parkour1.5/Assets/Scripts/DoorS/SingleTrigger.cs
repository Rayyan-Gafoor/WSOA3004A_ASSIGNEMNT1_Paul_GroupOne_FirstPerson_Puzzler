using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SingleTrigger : MonoBehaviour
{
    public Vector3 EndPos;
    public Vector3 Movementsize;
    public float Speed = 1.0f;

    [SerializeField] GameObject Door;

    
    bool opening = false;
    Vector3 StartPos;
    float delay = 0.0f;

    // Start is called before the first frame update
    void Start()
    {
        StartPos = Door.transform.position;
        EndPos = StartPos;
        EndPos = EndPos + Movementsize;
       // Debug.Log(StartPos + "is Start");
       // Debug.Log(EndPos + "is end");
    }

    // Update is called once per frame
    void Update()
    {
        if (opening)
        {
            MoveDoor(EndPos,(Speed*2f));
        }
        else if(!opening)
        {
            MoveDoor(StartPos,Speed);
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            opening = true;
            
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            opening = false;
            
        }
    }
    void MoveDoor(Vector3 GoalPos, float MoveSp)
    {
        float dis = Vector3.Distance(Door.transform.position, GoalPos);
        if (dis > .1f) 
        {
            Door.transform.position = Vector3.Lerp(Door.transform.position, GoalPos, MoveSp * Time.deltaTime);
        }
      
    }
   
}
