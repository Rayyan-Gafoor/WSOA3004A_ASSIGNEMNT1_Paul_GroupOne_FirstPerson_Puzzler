using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorScriots : MonoBehaviour
{
    public GameObject[] doors;
    public Vector3 maxOpen;
    public Vector3 maxClose;
    public Vector3 MaxSlide;
    public float DoorSpeed;

    [SerializeField] int ActiveDoor;
    bool trigger;
    //bool open;


    // Start is called before the first frame update
    void Start()
    {
        trigger = false;
        CheckDoorPosition();
        //open = false;
    }

    // Update is called once per frame
    void Update()
    {
       
        Door();
        
    }
    void Door()
    {
        if (trigger)
        {
            Debug.Log("trigger active");
            StartCoroutine(Slide(doors[ActiveDoor], maxOpen, maxClose, DoorSpeed, MaxSlide));
            
           /* if (doors[ActiveDoor].transform.position.x <  2.25)
            {
                Debug.Log("Openeing");
                doors[ActiveDoor].transform.Translate(DoorSpeed * Time.deltaTime, 0f, 0f);
            }*/
           
        }
        if (!trigger)
        {
            Debug.Log("trigger deactivated");
          
            StartCoroutine(Slide(doors[ActiveDoor], maxClose , maxOpen, DoorSpeed, -MaxSlide));
            /*
            if (doors[ActiveDoor].transform.position.x > -18)
            {
                Debug.Log("Closing");
                doors[ActiveDoor].transform.Translate(-DoorSpeed * Time.deltaTime, 0f, 0f);
            }*/

        }
    }
    void CheckDoorPosition()
    {
        maxOpen = new Vector3(doors[ActiveDoor].transform.position.x, doors[ActiveDoor].transform.position.y, doors[ActiveDoor].transform.position.z);
        maxClose = new Vector3(doors[ActiveDoor].transform.position.x, doors[ActiveDoor].transform.position.y, doors[ActiveDoor].transform.position.z);
        Debug.Log("size of x = " + maxOpen);
        
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            trigger = true;
        }
        
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            trigger = false;
        }
    }
    IEnumerator Slide(GameObject door , Vector3 startPos, Vector3 endPos, float time, Vector3 MaxMovement)

    {
        float i = 0.0f;
        float rate = 1.0f / time;
        while (i < 1.0f)
        {
            i += Time.deltaTime * rate;
            door.transform.position = Vector3.Lerp(startPos, endPos - MaxMovement, i);
            yield return null;
        }
    }
}
