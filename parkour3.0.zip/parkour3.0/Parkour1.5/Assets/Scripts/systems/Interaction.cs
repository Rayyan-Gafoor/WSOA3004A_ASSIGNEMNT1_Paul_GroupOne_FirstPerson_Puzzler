using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum InteractionType
{
    Button
    // can add more interactable objects 
    // if more objects are added we will need to change the script to cater for them
    // but for the purpose of just having a button for the platforms this works for the prototype.
}
public class Interaction : MonoBehaviour
{
    public InteractionType component = InteractionType.Button;
    public bool active = false;

    public Vector3 EndPos;
    public Vector3 Movementsize;
    public float Speed = 1.0f;

    [SerializeField] GameObject Door;
   
    Vector3 StartPos;

    // Start is called before the first frame update
    void Start()
    {
        StartPos = Door.transform.position;
        EndPos = StartPos;
        EndPos = EndPos + Movementsize;
    }

    // Update is called once per frame
    void Update()
    {
        if (active)
        {
            MovePlatform(EndPos, (Speed * 2f));
        }
        else if (!active)
        {
            MovePlatform(StartPos, Speed);
        }
    }
    void MovePlatform(Vector3 GoalPos, float MoveSp)
    {
        float dis = Vector3.Distance(Door.transform.position, GoalPos);
        if (dis > .1f)
        {
            Door.transform.position = Vector3.Lerp(Door.transform.position, GoalPos, MoveSp * Time.deltaTime);
        }

    }
}
