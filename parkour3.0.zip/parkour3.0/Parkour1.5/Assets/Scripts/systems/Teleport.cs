using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Teleport : MonoBehaviour
{
    public Transform[] targets;
    public int targetNumber;
    public GameObject Player;
  
    private void Start()
    {
       
    }
    private void OnTriggerEnter(Collider other)
    {
        if (Vector3.Distance(transform.position, Player.transform.position) > 1f)
        {

            StartCoroutine(Teleportation());
        }

    }
    IEnumerator Teleportation()
    {
        //yield return new WaitForSeconds(1f);
        Player.transform.position = targets[targetNumber].transform.position;
        yield return new WaitForSeconds(1f);
    }
}
