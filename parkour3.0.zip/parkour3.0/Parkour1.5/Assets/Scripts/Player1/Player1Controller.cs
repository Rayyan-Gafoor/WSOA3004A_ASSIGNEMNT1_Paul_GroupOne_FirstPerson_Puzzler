using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Player1Controller : MonoBehaviour
{
    //Movement
    [Header("Movement")]
    public float Speed;
    public float Jump;
    public float groundDrag;
    public float AirDrag;
    public float AirMass;
    public float GroundMass;
    public Vector3 gravityInput;
    public Vector3 MoveVector;
    

   [SerializeField] Rigidbody rb;
    [SerializeField] Transform GroundCheck;
    [SerializeField] LayerMask Ground;
   // [SerializeField] float FallMulti = 2.5f;

    bool isGrounded;
    Vector3 PlayerMove;
    //Crouch Variables
    public bool isCrouched = false;

    [SerializeField] float CrouchScale = 0.5f;// could allow for different sizes as a game mech
    Vector3 temp;
    //Camera
    [Header("Camera Input")]
    [SerializeField] float Sensitivity;
    [SerializeField] Camera PlayerCam;
  

    Vector2 Mouse;
    float xRotation;

    //Charcter Control
    [Header("Character Controller Substitute")]
    [SerializeField] GameObject Ray1;
    [SerializeField] GameObject Ray2;
    [SerializeField] float MaxStepHeight = 0.3f;
    [SerializeField] float Smooth = 0.1f;

    // Interacting
    public float RayDistance = 100f;
    public Interaction sense;

    void Awake()
    {
        
        Ray1.transform.position = new Vector3(Ray1.transform.position.x, MaxStepHeight, Ray1.transform.position.z);
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    // Update is called once per frame
    void Update()
    {
        PlayerMove = new Vector3(Input.GetAxis("Horizontal"), 0f, Input.GetAxis("Vertical"));
        Mouse = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));

        MovePlayer();
        MoveCamera();
        GravityControl();
        objectInteraction();
        if (Input.GetKeyDown(KeyCode.C))
        {
            Crouch();
        }



    }
    private void FixedUpdate()
    {
        Climb();
    }
    void MovePlayer()
    {
        //Move Player
         MoveVector = transform.TransformDirection(PlayerMove) * Speed;
        rb.velocity = new Vector3(MoveVector.x, rb.velocity.y, MoveVector.z);

        //Jumping
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if(Physics.CheckSphere(GroundCheck.position, 0.1f, Ground))
            {
                rb.AddForce(Vector3.up * Jump, ForceMode.Impulse);
            }
            
        }
        
    }
    void MoveCamera()
    {
        xRotation -= Mouse.y * Sensitivity;

        transform.Rotate(0f, Mouse.x* Sensitivity, 0f);
        PlayerCam.transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);
    }
    void Crouch()
    {
        if (!isCrouched)
        {
            temp = transform.localScale;
            temp.y = CrouchScale;

            transform.localScale = temp;
            isCrouched = true;
            Debug.Log("Is crouching");
            return;
        }
        else if (isCrouched)
        {
            temp = transform.localScale;
            temp.y = 1f;

            transform.localScale = temp;
            isCrouched = false;
            Debug.Log("Is Standing");
            return;
        }
    }
    void Climb()
    {
        RaycastHit hitLower;
        if (Physics.Raycast(Ray2.transform.position, transform.TransformDirection(Vector3.forward), out hitLower, 0.1f))
        {
            RaycastHit hitUpper;
            if (!Physics.Raycast(Ray1.transform.position, transform.TransformDirection(Vector3.forward), out hitUpper, 0.2f))
            {
                rb.position -= new Vector3(0f, -Smooth, 0f);
            }

        }

        RaycastHit hitLowerAngle;
        if (Physics.Raycast(Ray2.transform.position, transform.TransformDirection(2f, 0, 1), out hitLowerAngle, 0.1f))
        {
            RaycastHit hitUpperAngle;
            if (!Physics.Raycast(Ray1.transform.position, transform.TransformDirection(2f, 0, 1), out hitUpperAngle, 0.2f))
            {
                rb.position -= new Vector3(0f, -Smooth, 0f);
            }

        }
        RaycastHit hitLowerNegAngle;
        if (Physics.Raycast(Ray2.transform.position, transform.TransformDirection(-2f, 0, 1), out hitLowerNegAngle, 0.1f))
        {
            RaycastHit hitUpperNegAngle;
            if (!Physics.Raycast(Ray1.transform.position, transform.TransformDirection(-2f, 0, 1), out hitUpperNegAngle, 0.2f))
            {
                rb.position -= new Vector3(0f, -Smooth, 0f);
            }

        }
    }
    void GravityControl()
    {
        if (Physics.CheckSphere(GroundCheck.position, 0.1f, Ground))
        {
            isGrounded = true;
            rb.drag = groundDrag;
            rb.mass = GroundMass;
        }
        else
        {
            isGrounded = false;
            if (!isGrounded)
            {
                rb.drag = AirDrag;
                rb.mass = AirMass;
                Physics.gravity = gravityInput;
            }
        }

    }
    void objectInteraction()
    {
        //Interaction
        // using this ray to point at different objects in the scene 
        Ray ray = PlayerCam.ScreenPointToRay(Input.mousePosition);
        // Debug.DrawRay(PlayerCam.transform.position, Input.mousePosition, Color.red);
        RaycastHit hit;
        //if this ray hits somthing within the given distance (RayDistance) check is if this object has the script for an interaction
        if (Physics.Raycast(ray, out hit, RayDistance))
        {
            // this is checking if it does have the script and then storing it in the obj var
            Interaction obj = hit.collider.GetComponent<Interaction>();
            // we wait for the players input and when recieved we then  make sure that that the obj var is not empty
            if (Input.GetMouseButtonDown(0) && obj != null)
            {
                // activator is called to activate and deactivate the object in the interaction script. 
                sense = obj;
                StartCoroutine(Activator());
                return;
            }
            else {return;}
        }
    }
    IEnumerator Activator()
    {
       // this change the actvation status of the object.
        if (sense.active == false)
        {
            sense.active = true;
            Debug.Log(sense.active);
            yield return new WaitForSeconds(5f);
        }

        else 
        {
            sense.active = false;
            Debug.Log(sense.active);
            yield return new WaitForSeconds(5f);

        }
        
    }
   

}
